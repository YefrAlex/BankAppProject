package de.YefrAlex.BankAppProject.entity.enums;

import org.springframework.security.core.GrantedAuthority;
import java.util.Collection;
import java.util.Iterator;
public enum Role {
    USER,
    ADMIN,
    MANAGER;
}
