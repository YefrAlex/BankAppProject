package de.YefrAlex.BankAppProject.entity.enums;

public enum ProductType {
    LOAN,
    AUTO_LOAN,
    MORTGAGE,
    DEPOSIT,
    DEBIT_CARD,
    CREDIT_CARD;
}
