package de.YefrAlex.BankAppProject.dto;

import de.YefrAlex.BankAppProject.entity.Account;
import lombok.*;
import java.util.Objects;
import java.util.Set;

@Getter
@Setter
public class ClientShortDto {
    String firstName;
    String lastName;
    String email;
    String phone;
    int numberOfAccounts;



    public ClientShortDto() {
    }



    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, email, phone);
    }

    @Override
    public String toString() {
        return "ClientShortDto{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", numberOfAccounts=" + numberOfAccounts +
                '}';
    }
}
