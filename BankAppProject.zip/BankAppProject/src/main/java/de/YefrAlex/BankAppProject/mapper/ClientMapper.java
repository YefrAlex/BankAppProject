package de.YefrAlex.BankAppProject.mapper;


import de.YefrAlex.BankAppProject.dto.ClientShortDto;
import de.YefrAlex.BankAppProject.entity.Client;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel="spring")
public interface ClientMapper {

    //@Mapping(source = "client.accounts", target = "accounts")
    ClientShortDto toClientShortDto (Client client);

}
