package de.YefrAlex.BankAppProject.entity.enums;

public enum AccountType {
    DEBIT, CREDIT, OTHER
}
