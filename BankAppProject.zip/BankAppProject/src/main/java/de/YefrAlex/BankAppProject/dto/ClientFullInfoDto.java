package de.YefrAlex.BankAppProject.dto;

import de.YefrAlex.BankAppProject.entity.enums.CurrencyCode;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;

@Getter
@Setter
public class ClientFullInfoDto {

    String firstName;
    String lastName;
    String taxCode;
    String email;
    String address;
    String phone;
    LocalDateTime createdAt;


    int numberOfAccounts;
    Map<BigDecimal, CurrencyCode> balances;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientFullInfoDto that=(ClientFullInfoDto) o;
        return numberOfAccounts == that.numberOfAccounts && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(taxCode, that.taxCode) && Objects.equals(email, that.email) && Objects.equals(address, that.address) && Objects.equals(phone, that.phone) && Objects.equals(createdAt, that.createdAt) && Objects.equals(balances, that.balances);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, taxCode, email, address, phone, createdAt, numberOfAccounts, balances);
    }

    @Override
    public String toString() {
        return "ClientFullInfoDto{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", taxCode='" + taxCode + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", createdAt=" + createdAt +
                ", numberOfAccounts=" + numberOfAccounts +
                ", balances=" + balances +
                '}';
    }
}

