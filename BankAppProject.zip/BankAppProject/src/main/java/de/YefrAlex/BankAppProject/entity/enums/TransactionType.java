package de.YefrAlex.BankAppProject.entity.enums;

public enum TransactionType {
    TRANSFER,
    PAYMENT,
    WITHDRAW,
    DEPOSIT;
}
