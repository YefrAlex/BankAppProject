package de.YefrAlex.BankAppProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAppProjectApplication.class, args);
	}

}
