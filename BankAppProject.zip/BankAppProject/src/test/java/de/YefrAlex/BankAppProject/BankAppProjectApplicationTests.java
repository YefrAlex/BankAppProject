package de.YefrAlex.BankAppProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAppProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
